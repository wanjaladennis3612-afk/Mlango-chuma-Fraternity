MLANGO CHUMA FRATERNITY APP — STEP 1

This package converts the existing Chama HTML prototype into an installable
Progressive Web App (PWA).

Current features retained:
- Member login
- Admin area
- 18 weeks
- Contributions
- Savings
- Loans
- Fines
- Withdrawals
- Attendance
- Reports

IMPORTANT:
This Step 1 version is still a prototype. Data is stored in the browser
(local storage) and is NOT yet a shared online database.

Next step:
Connect the app to a secure cloud database and authentication.
